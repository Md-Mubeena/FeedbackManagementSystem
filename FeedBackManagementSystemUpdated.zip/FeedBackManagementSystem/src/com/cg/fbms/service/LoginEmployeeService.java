package com.cg.fbms.service;

import com.cg.fbms.dao.EmployeeDAO;
import com.cg.fbms.dao.ILoginDAO;
import com.cg.fbms.dao.LoginDAOImpl;
import com.cg.fbms.dto.Employee;

public class LoginEmployeeService implements ILoginEmployee{

	private String employeeRole =null;
	private String employeeName = null;
	
	@Override
	public boolean loginAuthentication(Employee employee) {
		
		boolean status = false;
		if(employee.getEmployeeId() > 1 &&  employee.getEmployeePassword()!=null && employee.getEmployeePassword()!="") {
			
			ILoginDAO loginDao = new LoginDAOImpl();
			Employee loginEmployee = loginDao.validateEmployee(employee);
			if(loginEmployee!=null) {
				employeeRole = loginEmployee.getEmployeeRole();
				employeeName = loginEmployee.getEmployeeName();
				status = true;
			}
				
			
		}
		 return status;
		
	}

	@Override
	public String getEmployeeRole() {
		// TODO Auto-generated method stub
		return employeeRole;
	}

	@Override
	public String getEmployeeName() {
		// TODO Auto-generated method stub
		return employeeName;
	}

}
