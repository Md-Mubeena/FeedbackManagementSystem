package com.cg.fbms.service;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*IEmployee employee = new EmployeeService();
		System.out.println(employee.getEmployeeNameById(101));
		*/
		IFeedbackReport fbreport = new FeedbackReportService();
		
		System.out.println(fbreport.getFbPendingParticipants());

		System.out.println("Default");
		System.out.println(fbreport.getFeedbackDefaulterReports());
	}

}
