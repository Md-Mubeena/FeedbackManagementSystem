package com.cg.fbms.service;

public interface IEmployee {
	
	public String getEmployeeNameById(int empId);
	
}
