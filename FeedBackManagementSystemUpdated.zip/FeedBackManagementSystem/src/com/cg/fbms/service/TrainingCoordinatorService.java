package com.cg.fbms.service;

import java.util.Date;
import java.util.List;

import com.cg.fbms.dao.ITrainingCoordinatorDAO;
import com.cg.fbms.dao.TrainingCoordinatorDAO;
import com.cg.fbms.dto.TrainingProgram;

public class TrainingCoordinatorService implements ITrainingCoordinatorService{

	ITrainingCoordinatorDAO coorodinatorDAO = new TrainingCoordinatorDAO();
	
	@Override
	public List<TrainingProgram> showTrainingCourse() {
		
		try {
			return coorodinatorDAO.showTrainingCourse();
		} catch (Exception e) {
			
			e.printStackTrace();
			return null;
		}

	}
	
	@Override
	public boolean addTrainingSession(TrainingProgram trainingProgram) {
			if(dateValidation(trainingProgram.getTrainingStartDate(), 
					trainingProgram.getTrainingEndDate())) { 
				System.out.println("Start date greater than End date");
						return coorodinatorDAO.addTrainingCourse(trainingProgram);
			}
			else 
				return coorodinatorDAO.addTrainingCourse(trainingProgram);
	}
	
	@Override
	public TrainingProgram findTrainingSession(int id) {
		return coorodinatorDAO.findTrainingCourse(id);
	}
	
	@Override
	public Boolean updateTrainingSession(TrainingProgram training) {
		if(dateValidation(training.getTrainingStartDate(), 
				training.getTrainingEndDate())) { 
			System.out.println("Start date greater than End date");
					return coorodinatorDAO.updateTrainingCourse(training);
		}
		else 
			return coorodinatorDAO.updateTrainingCourse(training);
	}
	
	@Override
	public Boolean deleteTrainingSession(int trainingId) {
		return coorodinatorDAO.deleteTrainingCourse(trainingId);
	}

	
	
	@Override
	public Boolean validateDuplicate(TrainingProgram trainingP) {
		return coorodinatorDAO.validateDuplicate(trainingP);
	}


	
	@Override
	public boolean dateValidation(Date startDate, Date endDate) {
		
		return endDate.compareTo(startDate)<0?true:false;
	}
}