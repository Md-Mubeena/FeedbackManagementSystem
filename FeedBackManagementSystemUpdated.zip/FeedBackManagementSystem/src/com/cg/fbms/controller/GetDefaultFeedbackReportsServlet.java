package com.cg.fbms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.dto.Faculty;
import com.cg.fbms.dto.FeedbackMaster;
import com.cg.fbms.dto.TrainingParticipantEnrollment;
import com.cg.fbms.dto.TrainingParticipantId;
import com.cg.fbms.dto.TrainingProgram;
import com.cg.fbms.service.EmployeeService;
import com.cg.fbms.service.FacultyMaintenanceService;
import com.cg.fbms.service.FeedbackReportService;
import com.cg.fbms.service.IEmployee;
import com.cg.fbms.service.IFacultyMaintenance;
import com.cg.fbms.service.IFeedbackReport;
import com.cg.fbms.service.ITrainingCoordinatorService;
import com.cg.fbms.service.TrainingCoordinatorService;

@WebServlet("/GetDefaultFeedbackReportsServlet")
public class GetDefaultFeedbackReportsServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<FeedbackMaster> incompleteFeedbackReport = new ArrayList<>();
		List<TrainingParticipantEnrollment> feedbackPendingParticipants = new ArrayList<>();
		ArrayList<String> facultyNamesForIncompleteFb = new ArrayList<>();
		ArrayList<String> participantNames = new ArrayList<>();
		IFeedbackReport fbReportService = null;
		IFacultyMaintenance facultyMaintenance = null;
		ITrainingCoordinatorService trainingCoordinatorService = null;
		TrainingParticipantId trainingParticipantId = null;
		TrainingProgram trainingProgram = null;
		IEmployee employee = null;
		
		try {
			fbReportService = new FeedbackReportService();
			
			incompleteFeedbackReport = fbReportService.getFeedbackDefaulterReports();
			
			facultyMaintenance = new FacultyMaintenanceService();
			Faculty faculty = null;
			
			int participantId = 0;
			String pName = "";
			
			System.out.println(incompleteFeedbackReport);
			
			trainingCoordinatorService = new TrainingCoordinatorService();
			employee = new EmployeeService();
			
			
			for(FeedbackMaster report: incompleteFeedbackReport) {
				faculty = facultyMaintenance.getFacultyById(report.getFacultyId());
				facultyNamesForIncompleteFb.add(faculty.getFacultyName());
				trainingParticipantId = report.getTrainingParticipantId();
				participantId = trainingParticipantId.getParticipantId();
				pName = employee.getEmployeeNameById(participantId);
				participantNames.add(pName);
			}
			
			feedbackPendingParticipants = fbReportService.getFbPendingParticipants();
			faculty = null;
			
			for (TrainingParticipantEnrollment trainingParticipant: feedbackPendingParticipants) {
				trainingParticipantId = trainingParticipant.getTrainingParticipantId();
				participantId = trainingParticipantId.getParticipantId();
				trainingProgram = trainingCoordinatorService.findTrainingSession(trainingParticipantId.getTrainingCode());
				faculty = facultyMaintenance.getFacultyById(trainingProgram.getFacultyId());
				facultyNamesForIncompleteFb.add(faculty.getFacultyName());
				pName = employee.getEmployeeNameById(participantId);
				participantNames.add(pName);
			}
			
			request.setAttribute("facultyNamesForIncompleteFb", facultyNamesForIncompleteFb);
			request.setAttribute("incompleteFbReport", incompleteFeedbackReport);
			request.setAttribute("participantNames", participantNames);
			
			request.setAttribute("fbPendingParticipants", feedbackPendingParticipants);
			
			request.getRequestDispatcher("defaultFeedbackReport.jsp").forward(request, response);
		}
		catch (Exception e) {
			request.setAttribute("ErrorMsg", "Sorry can't connect to database.");
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
		
	}
	
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}
}


