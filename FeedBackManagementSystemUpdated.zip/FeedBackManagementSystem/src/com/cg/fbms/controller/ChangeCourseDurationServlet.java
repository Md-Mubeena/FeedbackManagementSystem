package com.cg.fbms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.service.CourseMaintenanceService;
import com.cg.fbms.service.ICourseMaintenance;

@WebServlet("/ChangeCourseDurationSevltet")
public class ChangeCourseDurationServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if(request.getSession().getAttribute("username")==null || request.getSession().getAttribute("username")!=null) {
			response.sendRedirect("welcome.jsp");
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Integer courseId = Integer.parseInt(request.getParameter("courseId"));
		Integer courseDays =Integer.parseInt(request.getParameter("courseDuration"));
		RequestDispatcher dispatcher = null;
		
		try {
			
				ICourseMaintenance updateCourseDays = new CourseMaintenanceService();
				if(updateCourseDays.changeCourseDuration(courseId, courseDays)){
					request.setAttribute("successMessage", "Coures Duration changed successfully");
					dispatcher = request.getRequestDispatcher("changeCourseDuration.jsp");
					dispatcher.forward(request, response);
				} else {
					request.setAttribute("errorMessage", "Some error occurred, please verify all details");
					dispatcher = request.getRequestDispatcher("changeCourseDuration.jsp");
					dispatcher.forward(request, response);
				}	
		}
		catch (Exception e) {
			// TODO: handle exception
			request.setAttribute("ErrorMsg", "Sorry can't connect to database.");
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
	}

}
