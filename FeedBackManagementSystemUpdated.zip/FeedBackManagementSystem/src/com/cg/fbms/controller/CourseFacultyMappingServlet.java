package com.cg.fbms.controller;

import java.io.IOException;

import javax.persistence.PersistenceException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.dto.CourseFacultyMapping;
import com.cg.fbms.service.CourseMaintenanceService;
import com.cg.fbms.service.FacultyMaintenanceService;
import com.cg.fbms.service.ICourseMaintenance;
import com.cg.fbms.service.IFacultyMaintenance;


@WebServlet("/CourseFacultyMapping")
public class CourseFacultyMappingServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
			// TODO Auto-generated method stub
			
		
		
		
		
		int courseId = Integer.parseInt(request.getParameter("selectedCourseName"));
		int facultyId = Integer.parseInt(request.getParameter("facultyList"));
		CourseFacultyMapping courseFacultyMapping = new CourseFacultyMapping(courseId ,facultyId);
		
		try {
			IFacultyMaintenance facutlyMaintenance = new FacultyMaintenanceService();
			boolean status = facutlyMaintenance.courseFacultyMapping(courseFacultyMapping);
			if(status) {
				System.out.println("true status");
				request.setAttribute("successMessage", "Mapping Successfull");
				
			}
			else {
				System.out.println("false status");
				request.setAttribute("errroMessage", "Some Error Occurred! Try again");
			}
			request.getRequestDispatcher("facultyMaintenance.jsp").forward(request, response);;
		}
		catch (PersistenceException p) {
			// TODO: handle exception
			System.err.println(p.getMessage());
			request.setAttribute("ErrorMsg", "Sorry can't connect to database.");
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
		
	}
	
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}
}
