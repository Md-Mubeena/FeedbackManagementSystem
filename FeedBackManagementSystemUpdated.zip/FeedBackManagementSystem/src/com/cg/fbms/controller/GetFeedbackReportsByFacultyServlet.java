package com.cg.fbms.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.dto.FeedbackMaster;
import com.cg.fbms.exception.FeedbackSystemException;
import com.cg.fbms.service.FeedbackReportService;
import com.cg.fbms.service.IFeedbackReport;

@WebServlet("/GetFeedbackReportsByFacultyServlet")
public class GetFeedbackReportsByFacultyServlet extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = null;
		ArrayList<FeedbackMaster> fbReportById = new ArrayList<>();
		IFeedbackReport fbReportService = null;
		FeedbackMaster avgRating = null;
		int facultyId = 0;
		System.out.println("hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
		
		try {
			fbReportService = new FeedbackReportService();
			
			facultyId = Integer.parseInt(request.getParameter("facultyId"));
			fbReportById = fbReportService.getTrainingProgReportByFaculty(facultyId);

			int reportSize = fbReportById.size();
			
			int avgCommSkillRating = 0;
			int avgClarificationRating = 0;
			int avgTimeMgmtRating = 0;
			int avgHandoutRating = 0;
			int avgNetworkRating = 0;
			
			if(fbReportById.isEmpty()) {
				
				request.setAttribute("errorMessage", "No feedback Report for the given Id");
				request.getRequestDispatcher("feedbackById.jsp").forward(request, response);
			
			} else {
			
				for(FeedbackMaster report: fbReportById) {
					
					avgCommSkillRating += report.getFbCommunicationSkill();
					avgClarificationRating += report.getFbClarifyDoubts();
					avgTimeMgmtRating += report.getFbTimeManagement();
					avgHandoutRating += report.getFbHandoutProvide();
					avgNetworkRating += report.getFbNetworkAvailability();
				}
				
				avgRating = new FeedbackMaster(avgCommSkillRating / reportSize, avgClarificationRating / reportSize, avgTimeMgmtRating / reportSize, avgHandoutRating / reportSize, avgNetworkRating / reportSize);
				
				request.setAttribute("fbReportById", fbReportById);
				request.setAttribute("avgRating", avgRating);
			System.out.println("WELCOME");
				request.getRequestDispatcher("feedbackReportsByFacultyId.jsp").forward(request, response);
			}
		}
		catch (Exception e) {
			System.err.println(e.getMessage());
			request.setAttribute("errorMessage", "Sorry can't connect to database.");
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
		
	}
	
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

}
