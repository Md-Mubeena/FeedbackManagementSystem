package com.cg.fbms.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.fbms.dto.Employee;
import com.cg.fbms.service.ILoginEmployee;
import com.cg.fbms.service.LoginEmployeeService;

public class LoginValidationTest {
	
	@Test
	public void validateLoginTest() {
		ILoginEmployee loginEmployee = new LoginEmployeeService();
		
		boolean actualResult  = loginEmployee.loginAuthentication(new Employee(61036,"keerthi123"));
		boolean expectedResult = true;
		assertEquals(expectedResult, actualResult);
		
		actualResult  = loginEmployee.loginAuthentication(new Employee(61036,"abc"));
		expectedResult = false;
		assertEquals(expectedResult, actualResult);
		
		actualResult  = loginEmployee.loginAuthentication(new Employee(-10,""));
		expectedResult = false;
		assertEquals(expectedResult, actualResult);
		
		actualResult  = loginEmployee.loginAuthentication(new Employee(61036,""));
		expectedResult = false;
		assertEquals(expectedResult, actualResult);
		
		actualResult  = loginEmployee.loginAuthentication(new Employee(0,""));
		expectedResult = false;
		assertEquals(expectedResult, actualResult);
		
		
	}

}
