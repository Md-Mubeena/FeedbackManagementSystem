package com.cg.fbms.dao;

public interface QueryConstants {
	//for facultyMaintenance
	final String GET_ALL_FACULTY_LIST = "SELECT fSkill FROM Faculty fSkill";
	final String GET_ALL_COURSE_LIST = "SELECT course FROM CourseMaster course";
	
	
	//for course faculty mapping
	final String GET_ALL_FACULTY_ID_BY_COURSENAME = "SELECT cRFMapping.facultyId FROM CourseFacultyMapping cRFMapping WHERE cRFMapping.courseId=?";
	final String CHECK_COURSE_EXISTENCE = "SELECT course FROM CourseMaster course WHERE course.courseName=?";
	/*//for Employee_master
	final String GET_EMPLOYEE_NAME_BY_ID = "SELECT emp.employeeName FROM Employee emp";
*/
	//queries for participant
	final String GET_PARTICIPANT_ENROLLMENT_LIST = "SELECT tParticipantEnroll FROM TrainingParticipantEnrollment  WHERE tParticipantEnroll.trainingParticipantId.participantId=?";
	
	
	//for feedback master
	final String GET_ALL_FEEDBACK_REPORTS = "SELECT fMaster FROM FeedbackMaster fMaster";
	final String GET_FEEDBACK_REPORTS_BY_FACULTY_ID = "SELECT fMaster FROM FeedbackMaster fMaster WHERE fMaster.facultyId = :arg1";
	final String GET_FB_PENDING_PARTICIPANTS = "SELECT tParticipantEnroll FROM TrainingParticipantEnrollment tParticipantEnroll WHERE NOT EXISTS "
			+ "(SELECT feedback.trainingParticipantId FROM FeedbackMaster feedback WHERE feedback.trainingParticipantId = tParticipantEnroll.trainingParticipantId)";
		
	//for training coordinator
	final String GET_ALL_TRAINING_COURE = "SELECT tProgram from TrainingProgram tProgram";
}