package com.cg.fbms.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;

import com.cg.fbms.dto.Employee;
import com.cg.fbms.utility.JPAUtility;

public class LoginDAOImpl implements ILoginDAO{
	

	
	
	@Override
	public Employee validateEmployee(Employee employee) {
		// TODO Auto-generated method stub

		Employee employeeInfo = null;
		
		
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		boolean status = false;
		try {
			employeeInfo = manager.find(Employee.class, employee.getEmployeeId());
			if(employeeInfo!=null && employeeInfo.getEmployeeName()!=null) {
				if(employeeInfo.getEmployeePassword().equals(employee.getEmployeePassword())) {
					status = true;
				}
			}
			
		} 
		catch (PersistenceException e) {
			System.err.println(e.getMessage());
		}
		return employeeInfo;
		
	}


	
	

}
