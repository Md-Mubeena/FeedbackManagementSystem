package com.cg.fbms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cg.fbms.dto.FeedbackMaster;
import com.cg.fbms.dto.TrainingParticipantEnrollment;
import com.cg.fbms.dto.TrainingParticipantId;
import com.cg.fbms.service.IParticipantService;
import com.cg.fbms.service.ParticipantService;
import com.cg.fbms.utility.LoggerUtility;

@WebServlet("/AddFeedbackReport")
public class AddFeedbackReportController extends HttpServlet {
	Logger logger = LoggerUtility.getLogger();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		IParticipantService participantService = new ParticipantService();
		TrainingParticipantId trainingParticipantId = null;
		int tMRadioValue = 0;
		int hPRadioValue = 0;
		int hSNRadioValue = 0;
		String comments = "";
		String suggestions = "";
		boolean status = false;
		try {

			int trainingId = Integer.parseInt(request.getParameter("inputTraining"));
			int participantId = Integer.parseInt(request.getSession().getAttribute("employeeId").toString());

			trainingParticipantId = new TrainingParticipantId(trainingId, participantId);
			System.out.println(trainingParticipantId);
			String feedbackDate = request.getParameter("inputDate");
			Date date = null;
			SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd");
			try {
				date = format.parse(feedbackDate);
			} catch (ParseException e) {
				System.out.println(e.getMessage());
			}

			int facultyId = Integer.parseInt(request.getParameter("inputFaculty"));

			int pCRadioValue = Integer.parseInt(request.getParameter("pcRadio"));

			int cDRadioValue = Integer.parseInt(request.getParameter("cdRadio"));

			if (request.getParameter("tmRadio") != null)
				tMRadioValue = Integer.parseInt(request.getParameter("tmRadio"));
			if (request.getParameter("hpRadio") != null)
				hPRadioValue = Integer.parseInt(request.getParameter("hpRadio"));
			if (request.getParameter("hsnRadio") != null)
				hSNRadioValue = Integer.parseInt(request.getParameter("hsnRadio"));
			if (request.getParameter("suggestion") != null)
				suggestions = request.getParameter("suggestion");
			if (request.getParameter("comments") != null)
				suggestions = request.getParameter("commnets");

			FeedbackMaster addFeedbackForm = new FeedbackMaster(date, facultyId, trainingParticipantId, pCRadioValue,
					cDRadioValue, tMRadioValue, hPRadioValue, hSNRadioValue, comments, suggestions);

			status = participantService.provideFeedback(addFeedbackForm);
			if (status) {
				request.setAttribute("successMessage", "Thank you!, Your response has been submitted");
				logger.info("Response submitted");
				request.getRequestDispatcher("participantHomePage.jsp").forward(request, response);
			} else {
				request.setAttribute("errorMessage", "Sorry Your Feedback is not submitted.");
				logger.info("Response is not submitted");
				request.getRequestDispatcher("participantHomePage.jsp").forward(request, response);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
			request.setAttribute("ErrorMsg", "Sorry can't connect to database.");
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}

	}

}
