package com.cg.fbms.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.dao.CourseMaintenanceDAO;
import com.cg.fbms.dao.ICourseMaintenanceDAO;
import com.cg.fbms.dto.CourseMaster;
import com.cg.fbms.service.CourseMaintenanceService;
import com.cg.fbms.service.ICourseMaintenance;

public class AddCourseServlet extends HttpServlet {
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String courseName = request.getParameter("courseName");
		Integer courseDays = Integer.parseInt(request.getParameter("courseDays"));
		
		CourseMaster courseMaster = new CourseMaster(courseName,courseDays);
		
		ICourseMaintenance acdao = new CourseMaintenanceService();
		if(acdao.addCourse(courseMaster))System.out.println("Course added Successfully");
		else System.out.println("Some Error occurred");
		
	}

}
