package com.cg.fbms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.dao.TrainingCoordinatorDAO;
import com.cg.fbms.dto.TrainingProgram;
import com.cg.fbms.service.ITrainingCoordinatorService;
import com.cg.fbms.service.TrainingCoordinatorService;
import com.cg.fbms.utility.JPAUtility;

@WebServlet("/AddTrainingSessionSession")
public class AddTrainingSessionServlet extends HttpServlet {
	
	
		@Override
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			
			
			ITrainingCoordinatorService service = new TrainingCoordinatorService();
			
			
			Integer courseId = Integer.parseInt(request.getParameter("courseId"));
			Integer facultyId = Integer.parseInt(request.getParameter("facultyId"));
			Date startDate = null;
			try {
				startDate = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("startDate"));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			Date endDate = null;
			try {
				endDate = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("endDate"));
			} catch (ParseException e) {
				e.printStackTrace();
			}
		
			if(service.dateValidation(startDate, endDate)){
				System.out.println("Start date greater than End date");
				request.getSession().setAttribute("errorStartDate", "Start date was greater than End date, please re-enter");
				response.sendRedirect("AddNewSession.jsp");
			}
			
	
			else
			{
				TrainingProgram TrainingP = new TrainingProgram(courseId,facultyId,startDate,endDate);
				Boolean duplicateEntry = service.validateDuplicate(TrainingP);
				if(!duplicateEntry) {
					request.getSession().setAttribute("errorDuplicate", "An entry with same CourseID exists");
					response.sendRedirect("AddNewSession.jsp");
				}
				else {
				boolean trainingsession = false;
				trainingsession = service.addTrainingSession(TrainingP);
				if(trainingsession)
					System.out.println("Data persisted");
				else
					System.out.println("Couldn't persist");
				}
			}
		   
		}
	}


