package com.cg.fbms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cg.fbms.dao.TrainingCoordinatorDAO;
import com.cg.fbms.dto.TrainingProgram;
import com.cg.fbms.service.ITrainingCoordinatorService;
import com.cg.fbms.service.TrainingCoordinatorService;
import com.cg.fbms.utility.JPAUtility;
import com.cg.fbms.utility.LoggerUtility;

import java.util.*;
@WebServlet("/AddTrainingSession")
public class AddTrainingSessionServlet extends HttpServlet {
	Logger logger = LoggerUtility.getLogger();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if(request.getSession().getAttribute("username")==null || request.getSession().getAttribute("username")!=null) {
			response.sendRedirect("welcome.jsp");
		}
	}
	
		@Override
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			
			
			ITrainingCoordinatorService service = new TrainingCoordinatorService();
			
			
			Integer courseId = Integer.parseInt(request.getParameter("selectedCourseName"));
			Integer facultyId = Integer.parseInt(request.getParameter("facultyList"));
			String startDate = request.getParameter("startDate");
			String endDate = request.getParameter("endDate");
			
			
			
			try {
				startDate = new SimpleDateFormat("yyyy-MM-dd").format(new SimpleDateFormat("dd/MM/yyyy").parse(startDate));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			try {
				endDate = new SimpleDateFormat("yyyy-MM-dd").format(new SimpleDateFormat("dd/MM/yyyy").parse(endDate));
			} catch (ParseException e) {
				e.printStackTrace();
			}
		
			
			Date sDate =null;
			try {
				sDate = new SimpleDateFormat("yyyy-MM-dd").parse(startDate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Date eDate = null;
			try {
				eDate = new SimpleDateFormat("yyyy-MM-dd").parse(endDate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if(service.dateValidation(sDate,eDate )){
				System.out.println("Start date greater than End date");
				request.getSession().removeAttribute("erroStartDate");
				request.getSession().setAttribute("errorStartDate", "Start date was greater than End date, please re-enter");
				response.sendRedirect("trainingProgram1.jsp");
			}
			
			try {
				TrainingProgram TrainingP = new TrainingProgram(courseId,facultyId,sDate,eDate);
				Boolean duplicateEntry = service.validateDuplicate(TrainingP);
				if(!duplicateEntry) {
					request.getSession().removeAttribute("erroStartDate");
					request.getSession().setAttribute("errorDuplicate", "An entry with same CourseID exists");
					response.sendRedirect("trainingProgram1.jsp");
				}
				else {
					boolean trainingsession = false;
					trainingsession = service.addTrainingSession(TrainingP);
					if(trainingsession) {
						request.setAttribute("successMessage", "Training Created successfully");
						logger.info("Training created succesfully");
						request.getRequestDispatcher("trainingProgram1.jsp").forward(request, response);

					}
						
					else {
						request.setAttribute("errorMessage", "Some error occurred, please verify all details");
						logger.info("Training session did not created");
						request.getRequestDispatcher("trainingProgram1.jsp").forward(request, response);
					}
					
				}
				
			}catch (PersistenceException p) {
				System.err.println(p.getMessage());
				request.getRequestDispatcher("error.jsp").forward(request, response);
			}
		   
		}
	}