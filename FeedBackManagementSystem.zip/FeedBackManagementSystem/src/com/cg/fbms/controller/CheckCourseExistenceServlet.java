package com.cg.fbms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cg.fbms.service.CourseMaintenanceService;
import com.cg.fbms.service.ICourseMaintenance;
import com.cg.fbms.utility.LoggerUtility;

@WebServlet("/CheckCourseExistence")
public class CheckCourseExistenceServlet extends HttpServlet {
	Logger logger = LoggerUtility.getLogger();
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String courseName = request.getParameter("courseName");
		;
		int courseId = 0;
		int identification = Integer.parseInt(request.getParameter("identification"));
		if (identification == 2) {
			courseId = Integer.parseInt(request.getParameter("courseId"));
		}

		RequestDispatcher dispatcher = null;
		try {
			ICourseMaintenance courseMaintenance = new CourseMaintenanceService();
			boolean isExist = courseMaintenance.checkCourseExistence(courseName);
			if (isExist) {
				request.setAttribute("identification", identification);
				request.setAttribute("errorMessage", "Course already exist");
				logger.info("Course already exists");
				if (identification == 2) {
					request.setAttribute("courseId", courseId);

				}
				dispatcher = request.getRequestDispatcher("courseMaintenance1.jsp");
				dispatcher.forward(request, response);

			} else {
				request.setAttribute("identification", identification);
				if (identification == 2) {
					request.setAttribute("courseId", courseId);

				}
				request.setAttribute("courseFine", 1);
				request.setAttribute("courseName", courseName);
				dispatcher = request.getRequestDispatcher("courseMaintenance1.jsp");
				dispatcher.forward(request, response);
			}

		} catch (Exception e) {
			
		}
	}
}
