package com.cg.fbms.controller;

import java.io.IOException;

import javax.persistence.PersistenceException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.cg.fbms.dto.CourseFacultyMapping;
import com.cg.fbms.service.CourseMaintenanceService;
import com.cg.fbms.service.FacultyMaintenanceService;
import com.cg.fbms.service.ICourseMaintenance;
import com.cg.fbms.service.IFacultyMaintenance;
import com.cg.fbms.utility.LoggerUtility;

@WebServlet("/CourseFacultyMapping")
public class CourseFacultyMappingServlet extends HttpServlet {
	Logger logger = LoggerUtility.getLogger();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int courseId = Integer.parseInt(request.getParameter("selectedCourseName"));
		int facultyId = Integer.parseInt(request.getParameter("facultyList"));
		CourseFacultyMapping courseFacultyMapping = new CourseFacultyMapping(courseId, facultyId);

		try {
			IFacultyMaintenance facutlyMaintenance = new FacultyMaintenanceService();
			boolean status = facutlyMaintenance.courseFacultyMapping(courseFacultyMapping);
			if (status) {
				request.setAttribute("successMessage", "Mapping Successfull");
				logger.info("Course and Faculty mapped");

			} else {
				request.setAttribute("errroMessage", "Some Error Occurred! Try again");
				logger.info("Course faculty didnt mapped");
			}
			request.getRequestDispatcher("facultyMaintenance1.jsp").forward(request, response);
			;
		} catch (PersistenceException p) {
			System.err.println(p.getMessage());
			request.setAttribute("ErrorMsg", "Sorry can't connect to database.");
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}
}
