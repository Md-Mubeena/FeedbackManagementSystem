package com.cg.fbms.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.cg.fbms.dto.Faculty;
import com.cg.fbms.service.FacultyMaintenanceService;
import com.cg.fbms.service.IFacutlyMaintenance;
import com.sun.xml.internal.bind.v2.model.util.ArrayInfoUtil;


@WebServlet("/GetMappedFaculty")
public class GetMappedFaculytWithCourseServlet extends HttpServlet{
	
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}
}
