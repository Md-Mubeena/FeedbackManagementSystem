package com.cg.fbms.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.service.CourseMaintenanceService;
import com.cg.fbms.service.ICourseMaintenance;


public class ChangeCourseDurationServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Integer courseId = Integer.parseInt(request.getParameter("courseId"));
		Integer courseDays =Integer.parseInt(request.getParameter("courseDays"));
		
		
		try {
			
				ICourseMaintenance updateCourseDays = new CourseMaintenanceService();
				if(updateCourseDays.changeCourseDuration(courseId, courseDays)){
					System.out.println("Course Duration updated successfully" );
				} else {
					System.out.println("Some error occurred Course Duration did not updated");
				}	
		}
		catch (Exception e) {
			// TODO: handle exception
			request.setAttribute("ErrorMsg", "Sorry can't connect to database.");
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
	}

}
