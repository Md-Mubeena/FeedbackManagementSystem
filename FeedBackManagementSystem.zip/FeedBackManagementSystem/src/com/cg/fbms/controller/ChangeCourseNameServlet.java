package com.cg.fbms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.coyote.Request;
import org.apache.log4j.Logger;

import com.cg.fbms.exception.CourseNotFoundException;
import com.cg.fbms.service.CourseMaintenanceService;
import com.cg.fbms.service.ICourseMaintenance;
import com.cg.fbms.utility.LoggerUtility;

@WebServlet("/ChangeCourseNameServlet")
public class ChangeCourseNameServlet extends HttpServlet {
	Logger logger = LoggerUtility.getLogger();
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getSession().getAttribute("username") == null
				|| request.getSession().getAttribute("username") != null) {
			response.sendRedirect("welcome.jsp");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Integer courseId = Integer.parseInt(request.getParameter("courseId"));
		String courseName = request.getParameter("courseName");
		RequestDispatcher dispatcher = null;

		try {

			ICourseMaintenance updateCourseName = new CourseMaintenanceService();
			if (updateCourseName.changeCourseName(courseId, courseName)) {
				request.setAttribute("successMessage", "Coures Name changed successfully");
				logger.info("Course name changed");
				dispatcher = request.getRequestDispatcher("courseMaintenance1.jsp");
				dispatcher.forward(request, response);
			} else {
				request.setAttribute("errorMessage", "Some error occurred, please verify all details");
				logger.info("course name did not changed");
				dispatcher = request.getRequestDispatcher("courseMaintenance1.jsp");
				dispatcher.forward(request, response);
			}
		} catch (CourseNotFoundException e) {
			request.setAttribute("ErrorMsg", "Sorry can't connect to database.");
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
	}

}
