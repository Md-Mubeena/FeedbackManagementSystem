package com.cg.fbms.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.fbms.service.CourseMaintainenceService;
import com.cg.fbms.service.ICourseMaintainence;

public class ChangeCourseNameServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer courseId = Integer.parseInt(request.getParameter("courseId"));
		String courseName = request.getParameter("courseName");
		
		ICourseMaintainence updateCourseName = new CourseMaintainenceService();
		if(updateCourseName.changeCourseName(courseId, courseName)){
			System.out.println("Course Name updated successfully" );
		} else {
			System.out.println("Some error occurred Course Name did not updated");
		}	
	}

}
