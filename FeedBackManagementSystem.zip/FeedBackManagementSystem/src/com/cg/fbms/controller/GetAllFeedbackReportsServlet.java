package com.cg.fbms.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.dto.Faculty;
import com.cg.fbms.dto.FeedbackMaster;
import com.cg.fbms.service.FacultyMaintenanceService;
import com.cg.fbms.service.FeedbackReportService;
import com.cg.fbms.service.IFacultyMaintenance;
import com.cg.fbms.service.IFeedbackReport;

@WebServlet("/GetAllFeedbackReportsServlet")
public class GetAllFeedbackReportsServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		ArrayList<FeedbackMaster> feedbackReport = new ArrayList<>();
		ArrayList<String> facultyNames = new ArrayList<>();
		IFeedbackReport fbReportService = null;
		IFacultyMaintenance facultyMaintenance = null;
		Faculty faculty = null;
		FeedbackMaster avgRating = null;

		try {
			fbReportService = new FeedbackReportService();
			feedbackReport = fbReportService.getTrainingProgReport();
			facultyMaintenance = new FacultyMaintenanceService();

			int reportSize = feedbackReport.size();

			int avgCommSkillRating = 0;
			int avgClarificationRating = 0;
			int avgTimeMgmtRating = 0;
			int avgHandoutRating = 0;
			int avgNetworkRating = 0;
			System.out.println("size in servlete " + feedbackReport.size());
			if (feedbackReport != null && feedbackReport.size() != 0) {
				for (FeedbackMaster report : feedbackReport) {
					faculty = facultyMaintenance.getFacultyById(report.getFacultyId());
					facultyNames.add(faculty.getFacultyName());
					avgCommSkillRating += report.getFbCommunicationSkill();
					avgClarificationRating += report.getFbClarifyDoubts();
					avgTimeMgmtRating += report.getFbTimeManagement();
					avgHandoutRating += report.getFbHandoutProvide();
					avgNetworkRating += report.getFbNetworkAvailability();
				}

				avgRating = new FeedbackMaster(avgCommSkillRating / reportSize, avgClarificationRating / reportSize,
						avgTimeMgmtRating / reportSize, avgHandoutRating / reportSize, avgNetworkRating / reportSize);
				request.setAttribute("feedbackReport", feedbackReport);
				request.setAttribute("facultyNames", facultyNames);
				request.setAttribute("avgRating", avgRating);
			}
			request.getRequestDispatcher("allFeedbackReports.jsp").forward(request, response);
		} catch (Exception e) {
			request.setAttribute("ErrorMsg", "Sorry can't connect to database.");
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}
}
