package com.cg.fbms.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.service.CourseMaintainenceService;
import com.cg.fbms.service.ICourseMaintainence;

public class GetCourseByIdServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer courseId = Integer.parseInt(request.getParameter("courseId"));
			
		ICourseMaintainence getCourseById = new CourseMaintainenceService();
		getCourseById.getCourseById(courseId);
	}

}
