package com.cg.fbms.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.fbms.service.CourseMaintenanceService;
import com.cg.fbms.service.ICourseMaintenance;

public class GetCourseByIdServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer courseId = Integer.parseInt(request.getParameter("courseId"));
			
		ICourseMaintenance getCourseById = new CourseMaintenanceService();
		getCourseById.getCourseById(courseId);
	}

}
