package com.cg.fbms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Feedback_Master")
public class FeedbackMaster {
	@Id
	private int trainingCode;
	private int participantId;
	private int fbCommunicationSkill;
	private int fbClarifyDoubts;
	private int fbTimeManagement;
	private int fbHandoutProvide;
	private int fbNetworkAvailability;
	private String fbComments;
	private String fbSuggestions;
	
	public FeedbackMaster() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public FeedbackMaster(int trainingCode, int fbCommunicationSkill, int fbClarifyDoubts,
			int fbTimeManagement, int fbHandoutProvide, int fbNetworkAvailability, String fbComments,
			String fbSuggestions) {
		super();
		this.trainingCode = trainingCode;
		this.fbCommunicationSkill = fbCommunicationSkill;
		this.fbClarifyDoubts = fbClarifyDoubts;
		this.fbTimeManagement = fbTimeManagement;
		this.fbHandoutProvide = fbHandoutProvide;
		this.fbNetworkAvailability = fbNetworkAvailability;
		this.fbComments = fbComments;
		this.fbSuggestions = fbSuggestions;
	}
	
	public FeedbackMaster(int trainingCode, int participantId, int fbCommunicationSkill, int fbClarifyDoubts,
			int fbTimeManagement, int fbHandoutProvide, int fbNetworkAvailability, String fbComments,
			String fbSuggestions) {
		super();
		this.trainingCode = trainingCode;
		this.participantId = participantId;
		this.fbCommunicationSkill = fbCommunicationSkill;
		this.fbClarifyDoubts = fbClarifyDoubts;
		this.fbTimeManagement = fbTimeManagement;
		this.fbHandoutProvide = fbHandoutProvide;
		this.fbNetworkAvailability = fbNetworkAvailability;
		this.fbComments = fbComments;
		this.fbSuggestions = fbSuggestions;
	}
	public int getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}
	public int getParticipantId() {
		return participantId;
	}
	public void setParticipantId(int participantId) {
		this.participantId = participantId;
	}
	public int getFbCommunicationSkill() {
		return fbCommunicationSkill;
	}
	public void setFbCommunicationSkill(int fbCommunicationSkill) {
		this.fbCommunicationSkill = fbCommunicationSkill;
	}
	public int getFbClarifyDoubts() {
		return fbClarifyDoubts;
	}
	public void setFbClarifyDoubts(int fbClarifyDoubts) {
		this.fbClarifyDoubts = fbClarifyDoubts;
	}
	public int getFbTimeManagement() {
		return fbTimeManagement;
	}
	public void setFbTimeManagement(int fbTimeManagement) {
		this.fbTimeManagement = fbTimeManagement;
	}
	public int getFbHandoutProvide() {
		return fbHandoutProvide;
	}
	public void setFbHandoutProvide(int fbHandoutProvide) {
		this.fbHandoutProvide = fbHandoutProvide;
	}
	public int getFbNetworkAvailability() {
		return fbNetworkAvailability;
	}
	public void setFbNetworkAvailability(int fbNetworkAvailability) {
		this.fbNetworkAvailability = fbNetworkAvailability;
	}
	public String getFbComments() {
		return fbComments;
	}
	public void setFbComments(String fbComments) {
		this.fbComments = fbComments;
	}
	public String getFbSuggestions() {
		return fbSuggestions;
	}
	public void setFbSuggestions(String fbSuggestions) {
		this.fbSuggestions = fbSuggestions;
	}
	@Override
	public String toString() {
		return "FeedbackMaster [trainingCode=" + trainingCode + ", participantId=" + participantId
				+ ", fbCommunicationSkill=" + fbCommunicationSkill + ", fbClarifyDoubts=" + fbClarifyDoubts
				+ ", fbTimeManagement=" + fbTimeManagement + ", fbHandoutProvide=" + fbHandoutProvide
				+ ", fbNetworkAvailability=" + fbNetworkAvailability + ", fbComments=" + fbComments + ", fbSuggestions="
				+ fbSuggestions + "]";
	}
	
	


}
