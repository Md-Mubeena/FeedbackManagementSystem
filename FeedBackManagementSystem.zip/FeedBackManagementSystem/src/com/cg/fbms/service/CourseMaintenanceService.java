package com.cg.fbms.service;

import java.util.ArrayList;

import com.cg.fbms.dao.CourseMaintenanceDAO;
import com.cg.fbms.dao.ICourseMaintenanceDAO;
import com.cg.fbms.dto.CourseMaster;
import com.cg.fbms.exception.CourseExistsException;
import com.cg.fbms.exception.CourseNotFoundException;

public class CourseMaintenanceService implements ICourseMaintenance {

	ICourseMaintenanceDAO courseMaintainDao = new CourseMaintenanceDAO();
	
	
	/***
	 * @description : Method to add a course
	 * @author : Mohammed Mubeena
	 * @param : cmaster
	 * @return : boolean
	 * @throws : CourseExistsException 
	 */
	@Override
	public boolean addCourse(CourseMaster courseMaster) throws CourseExistsException{
		if (courseMaster.getCourseName() != null && courseMaster.getCourseDays() != 0
				&& courseMaster.getCourseName() != "") {
			boolean newCourseStatus = courseMaintainDao.addCourse(courseMaster);
			return newCourseStatus;
		}
		return false;
	}

	
	
	/***
	 * @description : Method to Update course name of a course that already exists
	 * @author :Mohammed Mubeena
	 * @param : courseId
	 * @param : courseName
	 * @return : boolean
	 * @throws : CourseNotFoundException
	 */
	@Override
	public boolean changeCourseName(int courseId, String courseName) throws CourseNotFoundException {

		boolean CourseNameStatus = courseMaintainDao.changeCourseName(courseId, courseName);
		return CourseNameStatus;

	}	

	/***
	 * @description : Method to Update course duration of a course that already exists
	 * @author : Mohammed Mubeena
	 * @param courseId
	 * @param courseDays
	 * @return : boolean
	 * @throws : CourseNotFoundException
	 */	
	@Override
	public boolean changeCourseDuration(int courseId, int courseDays) throws CourseNotFoundException{
		boolean CourseDuratioStatus = courseMaintainDao.changeCourseDuration(courseId, courseDays);
		return CourseDuratioStatus;
	}


	/***
	 * @description : Method to fetch courses by ID's
	 * @author : Mohammed Mubeena
	 * @param : courseId
	 * @return : CourseMaster
	 * @throws : CourseNotFoundException
	 */	
	@Override
	public CourseMaster getCourseById(int courseId) throws CourseNotFoundException{
		return courseMaintainDao.getCourseById(courseId);
	}

	
	/***
	 * @description : Method to get list of courses
	 * @author : Mohammed Mubeena
	 * @return : ArrayList
	 */	
	@Override
	public ArrayList<CourseMaster> getAllCourse() {
		return courseMaintainDao.getAllCourse();
	}

	

	/***
	 * @description : Method to check the course existence
	 * @author : Abhishek kumar
	 * @param courseName
	 * @return boolean
	 */
	@Override
	public boolean checkCourseExistence(String courseName) {
		return courseMaintainDao.checkCourseExistence(courseName);
	}

		
	/***
	 * @description : Method to get course by the course name
	 * @author : Abhishek kumar
	 * @param courseName
	 * @return : courseMaster
	 */	
	@Override
	public CourseMaster getCourseByCourseName(String courseName) {
		return courseMaintainDao.getCourseByCourseName(courseName);
	}

}
