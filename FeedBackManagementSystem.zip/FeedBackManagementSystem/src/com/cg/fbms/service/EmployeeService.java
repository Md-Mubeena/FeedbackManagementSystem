package com.cg.fbms.service;

import com.cg.fbms.dao.EmployeeDAO;
import com.cg.fbms.dao.IEmployeeDAO;
import com.cg.fbms.exception.UserNotFoundException;

public class EmployeeService implements IEmployee {

	IEmployeeDAO employeeDAO = new EmployeeDAO();

	/***
	 * @description : Method to get Employee's name by ID
	 * @author : Susanthika
	 * @param : empId
	 * @return : String
	 */
	@Override
	public String getEmployeeNameById(int empId) throws UserNotFoundException{
		return employeeDAO.getEmployeeNameById(empId);
	}

}
