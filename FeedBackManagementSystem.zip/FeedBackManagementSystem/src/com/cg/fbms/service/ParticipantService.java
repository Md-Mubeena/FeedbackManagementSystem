package com.cg.fbms.service;

import java.util.List;

import com.cg.fbms.dao.IParticipantDAO;
import com.cg.fbms.dao.ParticipantDAO;
import com.cg.fbms.dto.FeedbackMaster;
import com.cg.fbms.dto.TrainingProgram;

public class ParticipantService implements IParticipantService {

	IParticipantDAO participantDAO = new ParticipantDAO();

	/***
	 * @description : Method for a participant to enroll for a new course
	 * @author : Rajesh Kumar
	 * @param : participantId
	 * @return : List<TrainingProgram>
	 */
	@Override
	public List<TrainingProgram> enrollTrainingProgram(int participantId) {

		return participantDAO.getTrainingProgram(participantId);
	}
	

	/***
	 * @description : Method for a participant to provide feedback for the course taken
	 * @author : Rajesh Kumar
	 * @param : participantFeedback
	 * @return : boolean
	 */
	@Override
	public boolean provideFeedback(FeedbackMaster participantFeedback) {

		return participantDAO.provideFeedback(participantFeedback);
	}

	/***
	 * @description : Method to get the provided feedback
	 * @author : Rajesh Kumar
	 * @param : participantId
	 * @return : List<FeedbackMaster>
	 */	
	@Override
	public List<FeedbackMaster> getProvidedFeedback(int participantId) {

		return participantDAO.getProvidedFeedback(participantId);
	}

	/***
	 * @description : Method to get list of trainings
	 * @author : Rajesh Kumar
	 * @param : participantId
	 * @return : List<Integer>
	 */
	@Override
	public List<Integer> getTrainingList(int participantId) {
		return participantDAO.getTrainingList(participantId);
	}

}
