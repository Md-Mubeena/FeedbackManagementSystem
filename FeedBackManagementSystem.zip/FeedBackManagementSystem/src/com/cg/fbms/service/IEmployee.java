package com.cg.fbms.service;

import com.cg.fbms.exception.UserNotFoundException;

public interface IEmployee {
	
	public String getEmployeeNameById(int empId) throws UserNotFoundException;
	}
