package com.cg.fbms.service;

import java.util.ArrayList;

import com.cg.fbms.dto.CourseMaster;
import com.cg.fbms.exception.CourseExistsException;
import com.cg.fbms.exception.CourseNotFoundException;

public interface ICourseMaintenance {

	public boolean addCourse(CourseMaster cmaster) throws CourseExistsException;

	public boolean changeCourseName(int courseId, String courseName)throws CourseNotFoundException;

	public boolean changeCourseDuration(int courseId, int courseDays)throws CourseNotFoundException;

	public CourseMaster getCourseById(int courseId)throws CourseNotFoundException;

	public ArrayList<CourseMaster> getAllCourse();

	public boolean checkCourseExistence(String courseName);

	public CourseMaster getCourseByCourseName(String courseName);

}