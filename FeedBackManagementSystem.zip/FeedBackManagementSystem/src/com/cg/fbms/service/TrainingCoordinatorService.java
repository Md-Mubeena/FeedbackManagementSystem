package com.cg.fbms.service;

import java.util.Date;
import java.util.List;

import com.cg.fbms.dao.ITrainingCoordinatorDAO;
import com.cg.fbms.dao.TrainingCoordinatorDAO;
import com.cg.fbms.dto.TrainingProgram;

public class TrainingCoordinatorService implements ITrainingCoordinatorService {

	ITrainingCoordinatorDAO coordinatorDAO = new TrainingCoordinatorDAO();

	/***
	 * @description : Method to show available training courses
	 * @author : Keerthi sai
	 * @return : List<TrainingProgram>
	 */
	@Override
	public List<TrainingProgram> showTrainingCourse() {

		try {
			return coordinatorDAO.showTrainingCourse();
		} catch (Exception e) {

			e.printStackTrace();
			return null;
		}
	}
	
	
	/***
	 * @description : Method to add new training session
	 * @author : Keerthi sai
	 * @param : trainingProgram
	 * @return : boolean
	 */
	@Override
	public boolean addTrainingSession(TrainingProgram trainingProgram) {
		if (dateValidation(trainingProgram.getTrainingStartDate(), trainingProgram.getTrainingEndDate())) {
			System.out.println("Start date greater than End date");
			return coordinatorDAO.addTrainingCourse(trainingProgram);
		} else
			return coordinatorDAO.addTrainingCourse(trainingProgram);
	}

	
	/***
	 * @description : Method to find training sessions
	 * @author : Keerthi sai
	 * @param : id
	 * @return : TrainingProgram
	 */
	@Override
	public TrainingProgram findTrainingSession(int id) {
		return coordinatorDAO.findTrainingCourse(id);
	}

	
	/***
	 * @description : Method to update training sessions
	 * @author : Keerthi sai
	 * @param : training
	 * @return : Boolean
	 */
	@Override
	public Boolean updateTrainingSession(TrainingProgram training) {
		if (dateValidation(training.getTrainingStartDate(), training.getTrainingEndDate())) {
			System.out.println("Start date greater than End date");
			return coordinatorDAO.updateTrainingCourse(training);
		} else
			return coordinatorDAO.updateTrainingCourse(training);
	}


	/***
	 * @description : Method to delete a training session
	 * @author : Keerthi sai 
	 * @param : trainingId
	 * @return : Boolean
	 */
	@Override
	public Boolean deleteTrainingSession(int trainingId) {
		return coordinatorDAO.deleteTrainingCourse(trainingId);
	}

	
	/***
	 * @description : Method to check duplicate of training program
	 * @author : Keerthi sai
	 * @param : trainingP
	 * @return : Boolean
	 */
	@Override
	public Boolean validateDuplicate(TrainingProgram trainingP) {
		return coordinatorDAO.validateDuplicate(trainingP);
	}

	

	/***
	 * @description : Method to check the course duration
	 * @author : Keerthi sai 
	 * @param : startDate
	 * @param : endDate
	 * @return : Boolean
	 */
	@Override
	public boolean dateValidation(Date startDate, Date endDate) {

		return endDate.compareTo(startDate) < 0 ? true : false;
	}

	
	/***
	 * @description : Method to get training Id of all available training program
	 * @author : Rajesh Kumar 
	 * @param :  no argument
	 * @return : List<Integer>
	 */
	@Override
	public List<Integer> getAllTrainingId() {
		return coordinatorDAO.getAllTrainingId();
	}

	/***
	 * @description : Method to get all Participant Id who not enrolled in any tarining program
	 * @author : Rajesh Kumar 
	 * @param :  trainingId
	 * @return : List<Integer>
	 */
	
	@Override
	public List<Integer> getAllParticipantIdList(int trainingId) {
		return coordinatorDAO.getAllParticipantIdList(trainingId);
	}

	/***
	 * @description : Method to add Participant
	 * @author : Rajesh kumar
	 * @param : trainingId
	 * @param : participantId
	 * @return : boolean
	 */
	@Override
	public boolean addParticipantEnrollment(int trainingId, int participantId) {
		return coordinatorDAO.addParticipantEnrollment(trainingId, participantId);
	}
}