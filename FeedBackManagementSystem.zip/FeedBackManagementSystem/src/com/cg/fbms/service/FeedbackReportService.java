package com.cg.fbms.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.fbms.dao.FeedbackReportDAO;
import com.cg.fbms.dao.IFeedbackReportDAO;
import com.cg.fbms.dto.FeedbackMaster;
import com.cg.fbms.dto.TrainingParticipantEnrollment;

public class FeedbackReportService implements IFeedbackReport {
	IFeedbackReportDAO feedbackReportDAO = new FeedbackReportDAO();
	
	
	/***
	 * @description : Method to get feedback of all training programs
	 * @author : Susanthika 
	 * @return : ArrayList
	 */
	@Override
	public ArrayList<FeedbackMaster> getTrainingProgReport() {
		ArrayList<FeedbackMaster> trainingReport = feedbackReportDAO.getTrainingProgReport();
		System.out.println("size in size" + trainingReport.size());
		return trainingReport;
	}
	
	
	/***
	 * @description : Method to get feedback of training program based on faculty
	 * @author : Susanthika  
	 * @param : facultyId
	 * @return : ArrayList
	 */
	@Override
	public ArrayList<FeedbackMaster> getTrainingProgReportByFaculty(int facultyId) {
		ArrayList<FeedbackMaster> trainingRepByFacultyId = feedbackReportDAO.getTrainingProgReportByFaculty(facultyId);
		return trainingRepByFacultyId;
	}

	
	/***
	 * @description : Method to get default feedback report
	 * @author : Susanthika 
	 * @return : ArrayList
	 */	
	@Override
	public List<FeedbackMaster> getFeedbackDefaulterReports() {
		List<FeedbackMaster> fbDefaulterReports = feedbackReportDAO.getFeedbackDefaulterReports();
		return fbDefaulterReports;
	}
 
	
	/***
	 * @description : Method to get report of participants whose feedback is pending
	 * @author : Susanthika
	 * @return : List<TrainingParticipantEnrollment>
	 */
	@Override
	public List<TrainingParticipantEnrollment> getFbPendingParticipants() {
		List<TrainingParticipantEnrollment> fbPendingParticipants = feedbackReportDAO.getFbPendingParticipants();
		return fbPendingParticipants;
	}

}