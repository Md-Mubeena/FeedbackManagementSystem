package com.cg.fbms.service;

import java.util.ArrayList;

import com.cg.fbms.dto.CourseFacultyMapping;
import com.cg.fbms.dto.CourseMaster;
import com.cg.fbms.dto.Faculty;
import com.cg.fbms.exception.FacultyException;

public interface IFacultyMaintenance {

	public boolean addFaculty(Faculty facultySkill) throws FacultyException;;

	public ArrayList<Faculty> getAllFacultyList();

	public Faculty getFacultyById(int facultyId) throws FacultyException;

	public ArrayList<Integer> getAllFacultyId();

	public ArrayList<Faculty> getFacultyBySkill(String courseName)throws FacultyException;;

	public boolean courseFacultyMapping(CourseFacultyMapping courseFacultyMapping);

	public ArrayList<Faculty> getMappedFacultyWithCourse(int courseId);

	public ArrayList<Faculty> getFacultyNotMappedWithCourse(CourseMaster courseMaster)throws FacultyException;

	public boolean isTrainingExist();

}
