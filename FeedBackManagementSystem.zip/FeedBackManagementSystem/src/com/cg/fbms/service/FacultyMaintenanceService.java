package com.cg.fbms.service;

import java.util.ArrayList;

import com.cg.fbms.dao.FacultyMaintenanceDAOImpl;
import com.cg.fbms.dao.IFacultyMaintenanceDAO;
import com.cg.fbms.dto.CourseFacultyMapping;
import com.cg.fbms.dto.CourseMaster;
import com.cg.fbms.dto.Faculty;
import com.cg.fbms.exception.FacultyException;

public class FacultyMaintenanceService implements IFacultyMaintenance {
	private IFacultyMaintenanceDAO facultyMaintenanceDao = new FacultyMaintenanceDAOImpl();

	/***
	 * @description : Method to add new faculty
	 * @author : Abhishek kumar
	 * @param : facultySkill
	 * @return : boolean
	 * @throws FacultyException 
	 */
	@Override
	public boolean addFaculty(Faculty faculty)throws FacultyException {
		if (faculty.getFacultyName() != null && faculty.getFacultySkillSet() != null
				&& !faculty.getFacultyName().equals("") && !faculty.getFacultySkillSet().equals("")) {
			return facultyMaintenanceDao.addFacultySkillSet(faculty);
		}
		return false;
	}

	
	/***
	 * @description : Method to get list of all faculty
	 * @author : Abhishek kumar
	 * @return : ArrayList
	 */
	@Override
	public ArrayList<Faculty> getAllFacultyList() {
		return facultyMaintenanceDao.displayAllFacultyList();
	}


	/***
	 * @description : Method to call faculty by ID
	 * @author : Abhishek kumar
	 * @param : facultyId
	 * @return : Faculty
	 * @throws FacultyException 
	 */
	@Override
	public Faculty getFacultyById(int facultyId) throws FacultyException {
		return facultyMaintenanceDao.displayFacultyById(facultyId);
	}

	/**** 
	 * @description : Method to get all facultyID
	 * @author : Abhishek kumar  
	 * @return : ArrayList
	 */
	@Override
	public ArrayList<Integer> getAllFacultyId() {
		return facultyMaintenanceDao.getAllFacultyId();
	}
	
	
	/***
	 * @description : Method to fetch faculty based on their skill set
	 * @author : Abhishek kumar   
	 * @param courseName
	 * @return : ArrayList
	 * @throws FacultyException 
	 */
	@Override
	public ArrayList<Faculty> getFacultyBySkill(String courseName) throws FacultyException {
		return facultyMaintenanceDao.getFacultyBySkill(courseName);
	}

	
	/***
	 * @description : Method to map course to a faculty
	 * @author : Abhishek kumar  
	 * @param : courseFacultyMapping
	 * @return: boolean
	 */
	@Override
	public boolean courseFacultyMapping(CourseFacultyMapping courseFacultyMapping) {
		return facultyMaintenanceDao.courseFacultyMapping(courseFacultyMapping);
	}

	
	/***
	 * @description : Method to get faculty who are mapped with course
	 * @author : Abhishek kumar   
	 * @param : courseId
	 * @return : ArrayList
	 */
	@Override
	public ArrayList<Faculty> getMappedFacultyWithCourse(int courseId) {
		return facultyMaintenanceDao.getMappedFacultyWithCourse(courseId);
	}
	
	
	/***
	 * @description : Method to get faculty who are not mapped with course 
	 * @author : Abhishek kumar
	 * @param : courseMaster
	 * @return : ArrayList
	 * @throws FacultyException 
	 */
	@Override
	public ArrayList<Faculty> getFacultyNotMappedWithCourse(CourseMaster courseMaster) throws FacultyException {
		return facultyMaintenanceDao.getFacultyNotMappedWithCourse(courseMaster);
	}

	
	/***
	 * @description : Method to check the existence of training 
	 * @author : Abhishek kumar
	 * @return : boolean
	 */
	@Override
	public boolean isTrainingExist() {
		return facultyMaintenanceDao.isTrainingExist();
	}

}
