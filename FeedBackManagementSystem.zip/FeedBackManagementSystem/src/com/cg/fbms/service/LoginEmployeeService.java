package com.cg.fbms.service;

import com.cg.fbms.dao.EmployeeDAO;
import com.cg.fbms.dao.ILoginDAO;
import com.cg.fbms.dao.LoginDAOImpl;
import com.cg.fbms.dto.Employee;

public class LoginEmployeeService implements ILoginEmployee {

	private String employeeRole = null;
	private String employeeName = null;

	
	/***
	 * @description : Method to check an Employee is valid or not
	 * @author : Abhishek kumar
	 * @param : employee
	 * @return : boolean
	 */
	@Override
	public boolean loginAuthentication(Employee employee) {

		boolean status = false;
		if (employee.getEmployeeId() > 1 && employee.getEmployeePassword() != null
				&& employee.getEmployeePassword() != "") {

			ILoginDAO loginDao = new LoginDAOImpl();
			Employee loginEmployee = loginDao.validateEmployee(employee);
			if (loginEmployee != null) {
				employeeRole = loginEmployee.getEmployeeRole();
				employeeName = loginEmployee.getEmployeeName();
				status = true;
			}
		}
		return status;
	}

	
	/***
	 * @description : Method to get an employee role
	 * @author : Abhishek kumar
	 * @return : String
	 */
	@Override
	public String getEmployeeRole() {
		return employeeRole;
	}
	
	
	/***
	 * @description : Method to get an employee's name
	 * @author : Abhishek kumar
	 * @return : String
	 */
	@Override
	public String getEmployeeName() {
		return employeeName;
	}

}
