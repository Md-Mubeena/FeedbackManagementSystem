package com.cg.fbms.service;

import com.cg.fbms.dto.Employee;

public interface ILoginEmployee {

	public boolean loginAuthentication(Employee employee);

	public String getEmployeeRole();

	public String getEmployeeName();

}
