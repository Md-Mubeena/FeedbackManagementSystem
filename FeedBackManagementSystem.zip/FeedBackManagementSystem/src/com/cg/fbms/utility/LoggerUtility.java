package com.cg.fbms.utility;

import org.apache.log4j.Logger;

public class LoggerUtility {
 
	static Logger fbmsLogger = null;
	
	static {
		fbmsLogger = Logger.getLogger(LoggerUtility.class);
		}
	public static Logger getLogger() {
		return fbmsLogger;
	}
	
	
}
