package com.cg.fbms.dao;

import com.cg.fbms.dto.Employee;
import com.cg.fbms.exception.UserNotFoundException;

public interface IEmployeeDAO {

	public boolean addEmployee(Employee employee) throws UserNotFoundException;
	
	public String getEmployeeNameById(int empId) throws UserNotFoundException;
	
}
