package com.cg.fbms.dao;

import java.util.ArrayList;

import com.cg.fbms.dto.CourseMaster;
import com.cg.fbms.exception.CourseExistsException;
import com.cg.fbms.exception.CourseNotFoundException;

public interface ICourseMaintenanceDAO {
	public boolean addCourse(CourseMaster courseMaster) throws CourseExistsException;

	public boolean changeCourseName(int courseId, String courseName) throws CourseNotFoundException;

	public boolean changeCourseDuration(int courseId, int courseDays) throws CourseNotFoundException;;

	public CourseMaster getCourseById(int courseId) throws CourseNotFoundException;;

	public ArrayList<CourseMaster> getAllCourse();

	public boolean checkCourseExistence(String courseName) ;

	public CourseMaster getCourseByCourseName(String courseName);
}
