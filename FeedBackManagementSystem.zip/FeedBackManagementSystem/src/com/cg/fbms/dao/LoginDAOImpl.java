package com.cg.fbms.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.cg.fbms.dto.Employee;
import com.cg.fbms.utility.JPAUtility;

public class LoginDAOImpl implements ILoginDAO, QueryConstants {

	@Override
	public Employee validateEmployee(Employee employee) {

		Employee employeeInfo = null;

		EntityManagerFactory factory = null;
		EntityManager manager = null;
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		boolean status = false;
		try {

			Query query = manager.createQuery(LOGIN_VALIDATION, Employee.class);
			query.setParameter(1, employee.getEmployeeId());
			query.setParameter(2, employee.getEmployeePassword());
			employeeInfo = (Employee) query.getSingleResult();

			if (employeeInfo != null && employeeInfo.getEmployeeName() != null) {
				if (employeeInfo.getEmployeePassword().equals(employee.getEmployeePassword())) {
					status = true;
				}
			}

		} catch (PersistenceException e) {
			System.err.println(e.getMessage());
		}
		return employeeInfo;

	}

}
