package com.cg.fbms.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.fbms.dto.Employee;
import com.cg.fbms.dto.TrainingParticipantEnrollment;
import com.cg.fbms.dto.TrainingProgram;
import com.cg.fbms.utility.JPAUtility;

public class ParticipantDAO implements IParticipantDAO{
	
	@Override
	public List<TrainingProgram> getTrainingProgram(int participantId) {
		// TODO Auto-generated method stub

		EntityManagerFactory factory = null;
		EntityManager manager = null;
		List<TrainingProgram> listProgram=new ArrayList<TrainingProgram>();

		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		System.out.println(participantId);
		String selectQuery = "select t from TrainingParticipantEnrollment t where t.id.participantId=?";
		TypedQuery<TrainingParticipantEnrollment> query = manager.createQuery(selectQuery,TrainingParticipantEnrollment.class);
		query.setParameter(1, participantId);
		
		List<TrainingParticipantEnrollment> list = query.getResultList();
		System.out.println(list);
		for(TrainingParticipantEnrollment program :list)
		{
			System.out.println(program.getId().getParticipantId()+" "+program.getId().getTrainingCode());
			TrainingProgram getProgram = manager.find(TrainingProgram.class,program.getId().getTrainingCode());
			System.out.println(getProgram);
			listProgram.add(getProgram);
		}
		//System.out.println(listProgram);
		return listProgram;
	}
	
	
	@Override
	public boolean feedbackProvided(int participantId) {
		// TODO Auto-generated method stub
		return false;
	}

}
