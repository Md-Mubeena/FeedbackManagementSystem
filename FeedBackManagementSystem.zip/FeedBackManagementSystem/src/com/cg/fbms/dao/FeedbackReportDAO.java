package com.cg.fbms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.cg.fbms.dto.FeedbackMaster;
import com.cg.fbms.utility.JPAUtility;


public class FeedbackReportDAO implements IFeedbackReportDAO, QueryConstants {

	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;

	@Override
	public ArrayList<FeedbackMaster> getTrainingProgReport() {
		
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();
		
		try {
			return (ArrayList<FeedbackMaster>) manager.createQuery(GET_ALL_FEEDBACK_REPORTS, FeedbackMaster.class).getResultList();
		} catch (PersistenceException e) {
			transaction.rollback();
			System.out.println(e.getMessage());
			return null;
		} 
		finally {
			manager.close();
			
		}
	}


	@Override
	public ArrayList<FeedbackMaster> getTrainingProgReportByFaculty(int facultyId) {
		
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();
		
		try {
			Query query = manager.createQuery(GET_FEEDBACK_REPORTS_BY_FACULTY_ID, FeedbackMaster.class);
			query.setParameter("arg1", facultyId);
			return (ArrayList<FeedbackMaster>) query.getResultList();
		} catch (PersistenceException e) {
			transaction.rollback();
			System.out.println(e.getMessage());
			return null;
		} 
		finally {
			manager.close();
			
		}
	}

}
