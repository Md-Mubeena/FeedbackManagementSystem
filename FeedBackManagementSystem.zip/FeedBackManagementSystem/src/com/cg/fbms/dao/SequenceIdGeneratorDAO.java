package com.cg.fbms.dao;

import java.io.Serializable;
import java.util.Properties;
import java.util.Random;

import javax.imageio.spi.ServiceRegistry;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.dialect.Dialect;
import org.hibernate.ejb.util.ConfigurationHelper;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.id.enhanced.SequenceStyleGenerator;
import org.hibernate.type.LongType;
import org.hibernate.type.Type;

public class SequenceIdGeneratorDAO extends SequenceStyleGenerator {

	private String numberFormat;

	@Override
	public Serializable generate(SessionImplementor session, Object object) throws HibernateException {
		return Integer.parseInt(String.format(numberFormat, super.generate(session, object)));
	}

	@Override
	public void configure(Type type, Properties params, Dialect dialect) throws MappingException {
		super.configure(LongType.INSTANCE, params, dialect);
		numberFormat = ConfigurationHelper.getInteger(generateRandomId()).toString();
	}

	public static int generateRandomId() {
		int m = (int) Math.pow(10, 4);
		int random_id = m + new Random().nextInt(9 * m);
		return random_id;
	}

}
