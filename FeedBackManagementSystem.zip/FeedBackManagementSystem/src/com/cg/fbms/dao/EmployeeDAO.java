package com.cg.fbms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;

import com.cg.fbms.dto.Employee;
import com.cg.fbms.dto.Faculty;
import com.cg.fbms.dto.FeedbackMaster;
import com.cg.fbms.exception.UserNotFoundException;
import com.cg.fbms.utility.JPAUtility;

public class EmployeeDAO implements IEmployeeDAO, QueryConstants {

	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;

	@Override
	public boolean addEmployee(Employee employee) throws UserNotFoundException{

		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();

		try {
			manager.persist(employee);
			transaction.commit();
			return true;
		} catch (PersistenceException e) {
			transaction.rollback();
			throw new UserNotFoundException("Exception : User not found");
			
			
		} finally {
			manager.close();
			factory.close();
		}

	}

	@Override
	public String getEmployeeNameById(int empId) throws UserNotFoundException{

		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		Employee employee = null;
		String empName = "";
		try {
			employee = manager.find(Employee.class, empId);
			empName = employee.getEmployeeName();
		} catch (PersistenceException e) {
			throw new UserNotFoundException("Exception : User not found");
		} finally {
			manager.close();

		}
		return empName;
	}

}
