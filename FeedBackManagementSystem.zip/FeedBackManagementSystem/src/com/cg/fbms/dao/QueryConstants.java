package com.cg.fbms.dao;

public interface QueryConstants {

	// login
	final String LOGIN_VALIDATION = "SELECT emp FROM Employee emp WHERE emp.employeeId=? AND emp.employeePassword=?";

	// for facultyMaintenance
	final String GET_ALL_FACULTY_LIST = "SELECT fSkill FROM Faculty fSkill";
	
	// course Maintenance
	final String GET_ALL_COURSE_LIST = "SELECT course FROM CourseMaster course";
	final String CHECK_COURSE_EXISTENCE = "SELECT course FROM CourseMaster course WHERE course.courseName=?";
	final String MAPPING_EXISTENCE = "SELECT cRFMapping FROM CourseFacultyMapping cRFMapping";

	// for course faculty mapping
	final String GET_ALL_FACULTY_ID_BY_COURSENAME = "SELECT cRFMapping.facultyId FROM CourseFacultyMapping cRFMapping WHERE cRFMapping.courseId=?";

	// queries for participant
	final String GET_PARTICIPANT_ENROLLMENT_LIST = "SELECT tParticipantEnroll FROM TrainingParticipantEnrollment  tParticipantEnroll WHERE tParticipantEnroll.trainingParticipantId.participantId=?";
	final String GET_PROVIDED_FEEDBACK_LIST = "SELECT fMaster.trainingParticipantId.trainingCode FROM FeedbackMaster fMaster WHERE  fMaster.trainingParticipantId.participantId=?";

	// for feedback master
	final String GET_ALL_FEEDBACK_REPORTS = "SELECT fMaster FROM FeedbackMaster fMaster";
	final String GET_FEEDBACK_REPORTS_BY_FACULTY_ID = "SELECT fMaster FROM FeedbackMaster fMaster WHERE fMaster.facultyId = :arg1";
	final String GET_FB_PENDING_PARTICIPANTS = "SELECT tParticipantEnroll FROM TrainingParticipantEnrollment tParticipantEnroll WHERE NOT exists "
			+ "(SELECT feedback.facultyId FROM FeedbackMaster feedback WHERE feedback.facultyId = tParticipantEnroll.trainingParticipantId)";

	// for training coordinator
	final String GET_ALL_TRAINING_COURSE = "SELECT tProgram FROM TrainingProgram tProgram";
}