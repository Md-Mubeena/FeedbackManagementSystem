package com.cg.fbms.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.cg.fbms.dto.CourseMaster;
import com.cg.fbms.exception.CourseExistsException;
import com.cg.fbms.exception.CourseNotFoundException;
import com.cg.fbms.utility.JPAUtility;
import com.cg.fbms.utility.LoggerUtility;

public class CourseMaintenanceDAO implements ICourseMaintenanceDAO, QueryConstants {
	Logger logger = LoggerUtility.getLogger();
	
	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;

	@Override
	public boolean addCourse(CourseMaster courseMaster)  throws CourseExistsException{

		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();

		boolean status = false;

		try {
			transaction.begin();
			manager.persist(courseMaster);
			transaction.commit();
			status = true;
		} catch (PersistenceException c) {
			transaction.rollback();
			throw new CourseExistsException("Course already exists"); 
			
		} finally {
			manager.close();
		}
		return status;
	}

	@Override
	public boolean changeCourseName(int courseId, String courseName) throws CourseNotFoundException{
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		boolean status = false;

		try {
			transaction.begin();
			CourseMaster courseMaster = manager.find(CourseMaster.class, courseId);
			courseMaster.setCourseName(courseName);
			transaction.commit();
			status = true;
			
		} catch (PersistenceException c) {
			transaction.rollback();
			throw new CourseNotFoundException("Course you are trying to update is not found");
		} finally {
			manager.close();
		}

		return status;

	}

	@Override
	public boolean changeCourseDuration(int courseId, int courseDays) throws CourseNotFoundException{
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		boolean status = false;

		try {
			transaction.begin();
			CourseMaster courseMaster = manager.find(CourseMaster.class, courseId);
			courseMaster.setCourseDays(courseDays);
			transaction.commit();
			status = true;
		} catch (PersistenceException c) {
			transaction.rollback();
			throw new CourseNotFoundException("Course you are trying to update is not found");
		} finally {
			manager.close();
		}

		return status;
	}

	@Override
	public CourseMaster getCourseById(int courseId) throws CourseNotFoundException{
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();

		CourseMaster courseMaster = null;

		try {
			courseMaster = manager.find(CourseMaster.class, courseId);

		} catch (PersistenceException c) {
			throw new CourseNotFoundException("Course you are trying to fetch is not found");
		} finally {
			manager.close();
		}

		return courseMaster;
	}

	@Override
	public ArrayList<CourseMaster> getAllCourse() {
		ArrayList<CourseMaster> allCourseList = new ArrayList<CourseMaster>();
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();

		try {
			allCourseList = (ArrayList<CourseMaster>) manager.createQuery(GET_ALL_COURSE_LIST, CourseMaster.class)
					.getResultList();
		} catch (PersistenceException p) {
			System.err.println(p.getMessage());
		} finally {
			manager.close();
		}

		return allCourseList;
	}

	@Override
	public boolean checkCourseExistence(String couresName) {
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		CourseMaster course = null;
		boolean status = false;
		try {
			Query query = manager.createQuery(CHECK_COURSE_EXISTENCE, CourseMaster.class);
			query.setParameter(1, couresName);
			course = (CourseMaster) query.getSingleResult();
			if (course != null) {
				status = true;
			}
		} catch (PersistenceException p) {
			System.err.println(p.getMessage());
		}
		return status;
	}

	@Override
	public CourseMaster getCourseByCourseName(String courseName) {
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		CourseMaster course = null;
		boolean status = false;
		try {
			Query query = manager.createQuery(CHECK_COURSE_EXISTENCE, CourseMaster.class);
			query.setParameter(1, courseName);
			course = (CourseMaster) query.getSingleResult();

		} catch (PersistenceException p) {
			System.err.println(p.getMessage());
		}
		return course;
	}

}
