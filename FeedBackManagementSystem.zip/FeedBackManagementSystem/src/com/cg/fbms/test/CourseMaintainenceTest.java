package com.cg.fbms.test;
import java.util.ArrayList;

import org.junit.Test;

import com.cg.fbms.dao.CourseMaintainenceDAO;
import com.cg.fbms.dao.ICourseMaintainenceDAO;
import com.cg.fbms.dto.CourseMaster;

import static org.junit.Assert.*;
public class CourseMaintainenceTest {
	//Need to implement In Process 
	
	/*@Test
	void getCourseMaintainaenceTest(){
		ICourseMaintainenceDAO coursemaintainDAO = new CourseMaintainenceDAO();
		ArrayList<CourseMaster> actualResult = coursemaintainDAO.addCourse();
		String expectedResult = "[]";
		assertEquals(expectedResult, actualResult.toString());
	}
	*/
}  
 