package com.cg.fbms.exception;

public class FacultyException extends Exception{
	
	public FacultyException(String message) {	
		super(message);
	}

}
