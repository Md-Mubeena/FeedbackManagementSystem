package com.cg.fbms.exception;

public class CourseNotFoundException extends Exception{
	public CourseNotFoundException(String message) {	
		super();
	}

}
