package com.cg.fbms.exception;

public class CourseExistsException  extends Exception{
	
	public CourseExistsException(String message) {	
		super(message);
	}

}
