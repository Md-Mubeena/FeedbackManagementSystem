package com.cg.fbms.service;

import java.util.ArrayList;

import com.cg.fbms.dto.Faculty;

public interface IFacutlyMaintenance {
	public boolean addFaculty(Faculty facultySkill);
	public ArrayList<Faculty> getAllFacultyList();
	public Faculty getFacultyById(int facultyId);
	public ArrayList<Integer> getAllFacultyId();
	public ArrayList<Faculty> getFaultyBySkill(String courseName);
	
}
