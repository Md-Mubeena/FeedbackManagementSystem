package com.cg.fbms.service;

import com.cg.fbms.dto.CourseMaster;

public interface ICourseMaintainence {
	public boolean addCourse(CourseMaster cmaster);
	public boolean changeCourseName(int courseId ,String courseName);
	
	public boolean changeCourseDuration(int courseId, int courseDays );

}
