package com.cg.fbms.service;

import java.util.ArrayList;

import com.cg.fbms.dao.FacultyMaintenanceDAOImpl;
import com.cg.fbms.dao.IFacultyMaintenanceDAO;
import com.cg.fbms.dto.Faculty;

public class FacultymaintenanceService implements IFacutlyMaintenance {

	private IFacultyMaintenanceDAO facultyMaintenanceDao = new FacultyMaintenanceDAOImpl();
	
	
	@Override
	public boolean addFaculty(Faculty facultySkill) {
		
		return facultyMaintenanceDao.addFacultySkillSet(facultySkill);
		
	}


	@Override
	public ArrayList<Faculty> getAllFacultyList() {
		// TODO Auto-generated method stub
		return facultyMaintenanceDao.diplayAllFacultyList();
		
	}


	@Override
	public Faculty getFacultyById(int facultyId) {
		// TODO Auto-generated method stub
		return facultyMaintenanceDao.diplayFacultyById(facultyId);
	}


	@Override
	public ArrayList<Integer> getAllFacultyId() {
		// TODO Auto-generated method stub
		return facultyMaintenanceDao.getAllFacultyId();
	}


	@Override
	public ArrayList<Faculty> getFaultyBySkill(String courseName) {
		// TODO Auto-generated method stub
		return facultyMaintenanceDao.getFaultyBySkill(courseName);
	}

}
