package com.cg.fbms.service;

import java.util.List;

import com.cg.fbms.dto.TrainingProgram;

public interface IParticipantService {
	
	public List<TrainingProgram> enrollTrainingProgram(int participantId);
	public boolean provideFeedback(int participantId);

}
