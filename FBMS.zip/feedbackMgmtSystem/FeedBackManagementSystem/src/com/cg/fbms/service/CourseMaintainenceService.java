package com.cg.fbms.service;

import com.cg.fbms.dao.CourseMaintainenceDAO;
import com.cg.fbms.dao.ICourseMaintainenceDAO;
import com.cg.fbms.dto.CourseMaster;

public class CourseMaintainenceService implements ICourseMaintainence{
	
	@Override
	public boolean addCourse(CourseMaster courseMaster) {
		
		ICourseMaintainenceDAO courseMaintainDao = new CourseMaintainenceDAO();
		boolean newCourseStatus = courseMaintainDao.addCourse(courseMaster);
		return newCourseStatus;
	}

	@Override
	public boolean changeCourseName(int courseId, String courseName) {
		// TODO Auto-generated method stub
		ICourseMaintainenceDAO courseMaintainDao = new CourseMaintainenceDAO();
		boolean CourseNameStatus = courseMaintainDao.changeCourseName(courseId, courseName);
		return CourseNameStatus;
		
		
		
	}

	@Override
	public boolean changeCourseDuration(int courseId, int courseDays) {
		// TODO Auto-generated method stub
		ICourseMaintainenceDAO courseMaintainDao = new CourseMaintainenceDAO();
		boolean CourseDuratioStatus = courseMaintainDao.changeCourseDuration(courseId, courseDays);
		return CourseDuratioStatus;
	}
	
}
