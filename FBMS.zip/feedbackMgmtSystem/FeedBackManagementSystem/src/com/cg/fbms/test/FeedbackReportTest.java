package com.cg.fbms.test;


import java.util.ArrayList;

import org.junit.Test;

import com.cg.fbms.dao.FeedbackReportDAO;
import com.cg.fbms.dao.IFeedbackReportDAO;
import com.cg.fbms.dto.FeedbackMaster;
import static org.junit.Assert.*;
class FeedbackReportTest {

	@Test
	void getTrainingProgReportTest() {
		IFeedbackReportDAO feedbackReportDAO = new FeedbackReportDAO();
		ArrayList<FeedbackMaster> actualResult = feedbackReportDAO.getTrainingProgReport();
		String expectedResult = "[FeedbackMaster [trainingCode=12, participantId=101, fbCommunicationSkill=4, fbClarifyDoubts=5, fbTimeManagement=4, fbHandoutProvide=3, fbNetworkAvailability=3, fbComments=Excellent, fbSuggestions=better connection], FeedbackMaster [trainingCode=13, participantId=102, fbCommunicationSkill=5, fbClarifyDoubts=5, fbTimeManagement=5, fbHandoutProvide=5, fbNetworkAvailability=5, fbComments=Excellent, fbSuggestions=Handouts copy], FeedbackMaster [trainingCode=14, participantId=103, fbCommunicationSkill=4, fbClarifyDoubts=4, fbTimeManagement=4, fbHandoutProvide=4, fbNetworkAvailability=4, fbComments=Good, fbSuggestions=Prints copy]]";
		assertEquals(expectedResult, actualResult.toString());
		
	}

	@Test
	void getTrainingProgReportByFacultyTest() {
		IFeedbackReportDAO feedbackReportDAO = new FeedbackReportDAO();
		ArrayList<FeedbackMaster> actualResult = feedbackReportDAO.getTrainingProgReportByFaculty(101);
		String expectedResult = "[FeedbackMaster [trainingCode=12, participantId=0, fbCommunicationSkill=4, fbClarifyDoubts=5, fbTimeManagement=4, fbHandoutProvide=3, fbNetworkAvailability=3, fbComments=Excellent, fbSuggestions=better connection]]";
		assertEquals(expectedResult, actualResult.toString());
	}
}
