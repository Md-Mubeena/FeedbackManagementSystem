package com.cg.fbms.dao;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;

import com.cg.fbms.dto.Faculty;
import com.cg.fbms.utility.JPAUtility;

public class FacultyMaintenanceDAOImpl implements IFacultyMaintenanceDAO,QueryConstants{

	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;
	
	private  ArrayList<Faculty> facultyList = null;
	
	
	@Override
	public boolean addFacultySkillSet(Faculty facultySkill) {
		// TODO Auto-generated method stub
		factory = JPAUtility.getFactory();
		manager  = factory.createEntityManager();
		transaction = manager.getTransaction();
		
		try {
			transaction.begin();
			manager.persist(facultySkill);
			transaction.commit();
			return true;
		}
		catch (PersistenceException p) {
			// TODO: handle exception
			transaction.rollback();
			System.out.println(p);
			return false;
		}
		
		finally {
			manager.close();
		}
		
		
	}

	@Override
	public ArrayList<Faculty> diplayAllFacultyList() {
		// TODO Auto-generated method stub
		factory = JPAUtility.getFactory();
		manager  = factory.createEntityManager();
		
		ArrayList<Faculty> facultyList =null;
		try {
			facultyList = (ArrayList<Faculty>) manager.createQuery(GET_ALL_FACULTY_LIST,Faculty.class).getResultList();			
		}
		catch (PersistenceException p) {
			System.out.println(p);			 
		}
		finally {
			manager.close();
		}
		 return facultyList;
	}

	@Override
	public Faculty diplayFacultyById(int facultyId) {
		// TODO Auto-generated method stub
		factory = JPAUtility.getFactory();
		manager  = factory.createEntityManager();
		Faculty faculty = null;
		try {
			 faculty = manager.find(Faculty.class, facultyId);
		}
		catch (PersistenceException p) {
			// TODO: handle exception
			
		}
		return faculty;
	}

	@Override
	public ArrayList<Integer> getAllFacultyId() {
		// TODO Auto-generated method stub
		ArrayList<Integer> allFaculytId = new ArrayList<Integer>();
		facultyList = new FacultyMaintenanceDAOImpl().diplayAllFacultyList();	
			
			
		for(Faculty faculty: facultyList) {
			allFaculytId.add(faculty.getFacultyId());
		}
		return allFaculytId;
	}

	@Override
	public ArrayList<Faculty> getFaultyBySkill(String courseName) {
		// TODO Auto-generated method stub
		
		facultyList = new FacultyMaintenanceDAOImpl().diplayAllFacultyList();
		ArrayList<Faculty> facultyHavingParticularSkill = new ArrayList<Faculty>();
		for(Faculty facultySkill : facultyList) {
			List<String> skillSet = Arrays.asList(facultySkill.getFacultySkillSet().split(","));
			if(skillSet.contains(courseName)) {
				facultyHavingParticularSkill.add(facultySkill);
			}
		}
		
		return facultyHavingParticularSkill;
	}
	
}
