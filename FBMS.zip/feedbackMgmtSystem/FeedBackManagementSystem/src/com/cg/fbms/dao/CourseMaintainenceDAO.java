package com.cg.fbms.dao;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;

import com.cg.fbms.dto.CourseMaster;
import com.cg.fbms.utility.JPAUtility;

public class CourseMaintainenceDAO implements ICourseMaintainenceDAO {
	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;
	
	@Override
	public boolean addCourse(CourseMaster courseMaster) {
		// TODO Auto-generated method stub
		
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();

		try {
			manager.persist(courseMaster);
			transaction.commit();
			return true;
		} catch (PersistenceException c) {
			transaction.rollback();
			System.out.println(c.getMessage());
			return false;
		} finally {
			manager.close();
			factory.close();
		}

	}

	@Override
	public boolean changeCourseName(int courseId, String courseName) {
		// TODO Auto-generated method stub
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();

		try {
			CourseMaster courseMaster = manager.find(CourseMaster.class, courseId);
			courseMaster.setCourseName(courseName);
			transaction.commit();
			return true;
		} catch (PersistenceException c) {
			transaction.rollback();
			System.out.println(c.getMessage());
			return false;
		} finally {
			manager.close();
			factory.close();
		}

	}

	@Override
	public boolean changeCourseDuration(int courseId, int courseDays) {
		// TODO Auto-generated method stub
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();

		try {
			CourseMaster courseMaster = manager.find(CourseMaster.class, courseId);
			courseMaster.setCourseDays(courseDays);
			transaction.commit();
			return true;
		} catch (PersistenceException c) {
			transaction.rollback();
			System.out.println(c.getMessage());
			return false;
		} finally {
			manager.close();
			factory.close();
		}
	}

}
