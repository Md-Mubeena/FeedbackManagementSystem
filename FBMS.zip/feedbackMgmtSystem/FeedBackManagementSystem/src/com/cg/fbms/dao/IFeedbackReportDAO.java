package com.cg.fbms.dao;

import java.util.ArrayList;

import com.cg.fbms.dto.FeedbackMaster;

public interface IFeedbackReportDAO {
	
	public ArrayList<FeedbackMaster> getTrainingProgReport();
	
	public ArrayList<FeedbackMaster> getTrainingProgReportByFaculty(int facultyId);

}
