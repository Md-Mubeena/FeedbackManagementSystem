package com.cg.fbms.dao;

public interface QueryConstants {
	//for facultyMaintenance
	final String GET_ALL_FACULTY_LIST = "SELECT fSkill FROM FacultySkill fSkill";
	final String GET_ALL_FACULTY_LIST_BY_ID = "SELECT fSkill FROM FacultySkill fSkill where fSkill.facultyId=?";
	
	
	

	
	final String GET_ALL_FEEDBACK_REPORTS = "SELECT fbm FROM FeedbackMaster fbm";
	final String GET_FEEDBACK_REPORTS_BY_FACULTY_ID = "SELECT new FeedbackMaster(fbm.trainingCode, fbm.fbCommunicationSkill, fbm.fbClarifyDoubts, fbm.fbTimeManagement, fbm.fbHandoutProvide, fbm.fbNetworkAvailability, fbm.fbComments, fbm.fbSuggestions) from FeedbackMaster fbm where fbm.participantId = :arg1";
}
